[app]
title = Plates Match
package.name = platesmatch
package.domain = org.plates
source.dir = .
source.include_exts = py,png,jpg,kv,atlas,ttf
version = 1.0
requirements = python3,kivy==2.3.0,sqlite3,openpyxl,et_xmlfile,arabic-reshaper,python-bidi==0.4.2,six,pyjnius,android,androidstorage4kivy
orientation = portrait
fullscreen = 0
android.api = 33
android.minapi = 24
android.archs = arm64-v8a
android.accept_sdk_license = True
android.allow_backup = True

[buildozer]
log_level = 2
warn_on_root = 1
