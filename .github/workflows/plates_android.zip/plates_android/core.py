"""منطق التطبيق بدون واجهة (بدون pandas ليخف حجم الـ APK): SQLite + Excel + المطابقة."""
import csv
import os
import re
import sqlite3
import urllib.parse
from datetime import date, datetime

from openpyxl import Workbook, load_workbook

_DIGITS = str.maketrans("٠١٢٣٤٥٦٧٨٩۰۱۲۳۴۵۶۷۸۹", "01234567890123456789")

ALIASES = {
    "plate": ["اللوحة", "رقم اللوحة", "لوحة", "رقم_اللوحة", "plate", "plate number", "plate_number", "platenumber"],
    "street": ["الشارع", "اسم الشارع", "الموقع", "الشارع/الموقع", "اسم الشارع/الموقع", "street", "location"],
    "vtype": ["النوع", "نوع المركبة", "نوع السيارة", "نوع_المركبة", "vehicle type", "vehicle_type", "type"],
    "date": ["التاريخ", "تاريخ التسجيل", "تاريخ المرور", "تاريخ الحركة", "date", "record date", "record_date"],
    "link": ["الرابط", "رابط", "رابط الموقع", "hyperlink", "link", "url"],
    "lat": ["lat", "latitude", "خط العرض"],
    "lon": ["lon", "lng", "longitude", "خط الطول"],
    "vin": ["الشاسيه", "رقم الشاسيه", "الشاسية", "رقم الشاصي", "vin", "chassis", "chassis number", "chassis_no"],
    "requester": ["الجهة", "الجهة الطالبة", "جهة", "الجهه", "requester", "entity", "bank", "company"],
}
_LOOKUP = {n.lower(): k for k, names in ALIASES.items() for n in names}

SCHEMA = """
CREATE TABLE IF NOT EXISTS records (
    id INTEGER PRIMARY KEY, plate TEXT NOT NULL, plate_norm TEXT NOT NULL,
    vtype TEXT NOT NULL DEFAULT '', street TEXT NOT NULL DEFAULT '', record_date TEXT NOT NULL,
    link TEXT NOT NULL DEFAULT '', lat REAL, lon REAL, vin TEXT NOT NULL DEFAULT ''
);
CREATE INDEX IF NOT EXISTS idx_records_plate ON records(plate_norm);
CREATE INDEX IF NOT EXISTS idx_records_date  ON records(record_date);
CREATE UNIQUE INDEX IF NOT EXISTS ux_records ON records(plate_norm, record_date, street);
"""


# ------------------------------------------------------------------ أدوات
def normalize_plate(value) -> str:
    """أرقام إنجليزية، حذف المسافات/التطويل/التشكيل، أ إ آ -> ا، ى -> ي، وأرقام اللوحة 4 خانات."""
    s = text(value).translate(_DIGITS).upper()
    s = re.sub(r"[\u064B-\u065F\u0670\u0640\u200b-\u200f\u202a-\u202e\ufeff]", "", s)
    s = s.replace("أ", "ا").replace("إ", "ا").replace("آ", "ا").replace("ى", "ي")
    s = re.sub(r"[\s\-_./\\|]", "", s)
    m = re.fullmatch(r"(\D+)(\d{1,4})", s)
    if m:
        return m.group(1) + m.group(2).zfill(4)
    m = re.fullmatch(r"(\d{1,4})(\D+)", s)
    if m:
        return m.group(1).zfill(4) + m.group(2)
    return s


def text(v) -> str:
    if v is None:
        return ""
    if isinstance(v, float) and v.is_integer():
        v = int(v)
    return str(v).strip()


def to_float(v):
    try:
        return float(v) if text(v) != "" else None
    except ValueError:
        return None


def parse_date(v, default: str) -> str:
    if isinstance(v, (datetime, date)):
        return v.strftime("%Y-%m-%d")
    s = text(v)
    for fmt in ("%Y-%m-%d", "%d/%m/%Y", "%d-%m-%Y", "%Y/%m/%d", "%d.%m.%Y", "%Y-%m-%d %H:%M:%S", "%d/%m/%Y %H:%M"):
        try:
            return datetime.strptime(s, fmt).strftime("%Y-%m-%d")
        except ValueError:
            continue
    return default


_PIN_RE = re.compile(r"\s*[\(\[]?\s*دبوس\s*\S*\s*[\)\]]?\s*$")


def maps_url(street="", link="", lat=None, lon=None, city="") -> str:
    """أولوية: رابط الملف > إحداثيات > بحث باسم الشارع (+ المدينة). تُحذف (دبوس N)."""
    link = (link or "").strip()
    if link.lower().startswith(("http://", "https://")):
        return link
    if lat is not None and lon is not None:
        return f"https://www.google.com/maps?q={lat},{lon}"
    q = " ".join(x for x in (_PIN_RE.sub("", street or "").strip(), (city or "").strip()) if x)
    return "https://www.google.com/maps/search/?api=1&query=" + urllib.parse.quote(q) if q else ""


def read_rows(path: str):
    """قراءة Excel/CSV كسجلات (dict بأسماء داخلية: plate, street, vtype, ...)."""
    if path.lower().endswith(".csv"):
        with open(path, newline="", encoding="utf-8-sig") as f:
            raw = csv.reader(f)
            yield from _rows_from(raw)
        return
    wb = load_workbook(path, read_only=True, data_only=True)
    try:
        yield from _rows_from(wb.active.iter_rows(values_only=True))
    finally:
        wb.close()


def _rows_from(rows):
    header = None
    for row in rows:
        if header is None:
            if not any(text(c) for c in row):
                continue
            header = [_LOOKUP.get(text(c).lower()) for c in row]
            if "plate" not in header:
                raise ValueError("لم أجد عمود اللوحة (اللوحة / رقم اللوحة / plate)")
            continue
        d = {}
        for k, v in zip(header, row):
            if k and k not in d:
                d[k] = v
        if text(d.get("plate")):
            yield d


# ------------------------------------------------------------------ قاعدة البيانات
def get_conn(path: str) -> sqlite3.Connection:
    conn = sqlite3.connect(path, check_same_thread=False)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA journal_mode=WAL")
    conn.execute("PRAGMA synchronous=NORMAL")
    conn.execute("PRAGMA temp_store=MEMORY")
    conn.executescript(SCHEMA)
    return conn


def stats(conn) -> dict:
    r = conn.execute("SELECT COUNT(*) n, MIN(record_date) a, MAX(record_date) b FROM records").fetchone()
    return {"rows": r["n"], "from": r["a"], "to": r["b"]}


_INS = ("INSERT OR IGNORE INTO records (plate, plate_norm, vtype, street, record_date, link, lat, lon, vin) "
        "VALUES (?,?,?,?,?,?,?,?,?)")


def import_file(conn, path: str, default_date: str, progress=None, batch_size=20000):
    """دمج ملف في السجلات. يرجع (المضاف، المكرر/المتجاهل)."""
    added = seen = 0
    batch = []

    def flush():
        nonlocal added, batch
        before = conn.total_changes
        with conn:
            conn.executemany(_INS, batch)
        added += conn.total_changes - before
        batch = []
        if progress:
            progress(seen)

    for r in read_rows(path):
        pn = normalize_plate(r.get("plate"))
        if not pn:
            continue
        seen += 1
        batch.append((text(r.get("plate")), pn, text(r.get("vtype")), text(r.get("street")),
                      parse_date(r.get("date"), default_date), text(r.get("link")),
                      to_float(r.get("lat")), to_float(r.get("lon")), text(r.get("vin"))))
        if len(batch) >= batch_size:
            flush()
    if batch:
        flush()
    return added, seen - added


def search_records(conn, plate="", street="", date_from="", date_to="", limit=300):
    where, params = [], []
    if plate.strip():
        p = normalize_plate(plate)
        where.append("plate_norm >= ? AND plate_norm < ?")
        params += [p, p + "\uffff"]
    if street.strip():
        where.append("street LIKE ?")
        params.append(f"%{street.strip()}%")
    if date_from.strip():
        where.append("record_date >= ?")
        params.append(date_from.strip())
    if date_to.strip():
        where.append("record_date <= ?")
        params.append(date_to.strip())
    sql = "SELECT * FROM records" + (" WHERE " + " AND ".join(where) if where else "")
    sql += " ORDER BY record_date DESC LIMIT ?"
    return [dict(r) for r in conn.execute(sql, params + [limit])]


def parse_pasted(txt: str, entity: str = ""):
    """سطر لكل لوحة: لوحة , جهة , شاسيه (الفاصل: فاصلة/تاب/؛)."""
    out = []
    for line in txt.splitlines():
        parts = [p.strip() for p in re.split(r"[,\t;،]", line) if p.strip()]
        if parts:
            out.append({"plate": parts[0], "requester": parts[1] if len(parts) > 1 else entity,
                        "vin": parts[2] if len(parts) > 2 else ""})
    return out


def targets_from_file(path: str, entity: str = ""):
    name = os.path.splitext(os.path.basename(path))[0]
    return [{"plate": text(r.get("plate")), "requester": text(r.get("requester")) or entity or name,
             "vin": text(r.get("vin"))} for r in read_rows(path)]


def run_match(conn, targets, latest_only=False, date_from="", date_to=""):
    """يرجع (النتائج، اللوحات التي لم تظهر، عدد المطلوب)."""
    seen, tl = set(), []
    for t in targets:
        pn = normalize_plate(t["plate"])
        key = (pn, t.get("requester", ""))
        if pn and key not in seen:
            seen.add(key)
            tl.append((pn, text(t["plate"]), t.get("requester", ""), t.get("vin", "")))
    conn.execute("DROP TABLE IF EXISTS temp.targets")
    conn.execute("CREATE TEMP TABLE targets (plate_norm TEXT, plate_in TEXT, requester TEXT, t_vin TEXT)")
    conn.executemany("INSERT INTO temp.targets VALUES (?,?,?,?)", tl)
    conn.execute("CREATE INDEX temp.idx_t ON targets(plate_norm)")
    sql = ("SELECT t.plate_norm, t.plate_in, r.plate, r.vtype, "
           "CASE WHEN t.t_vin <> '' THEN t.t_vin ELSE r.vin END AS vin, t.requester, "
           "r.street, r.record_date, r.link, r.lat, r.lon "
           "FROM temp.targets t JOIN records r ON r.plate_norm = t.plate_norm")
    params = []
    if date_from.strip():
        sql += " AND r.record_date >= ?"
        params.append(date_from.strip())
    if date_to.strip():
        sql += " AND r.record_date <= ?"
        params.append(date_to.strip())
    sql += " ORDER BY r.record_date DESC"
    rows = [dict(r) for r in conn.execute(sql, params)]
    conn.execute("DROP TABLE IF EXISTS temp.targets")
    if latest_only:
        first, uniq = set(), []
        for r in rows:
            k = (r["plate_norm"], r["requester"])
            if k not in first:
                first.add(k)
                uniq.append(r)
        rows = uniq
    matched = {r["plate_norm"] for r in rows}
    unmatched = [{"plate": t[1], "requester": t[2]} for t in tl if t[0] not in matched]
    return rows, unmatched, len(tl)


def export_xlsx(rows, path: str, city: str = ""):
    """تصدير النتائج إلى Excel (من اليمين لليسار) مع جعل الشارع رابطاً نشطاً."""
    wb = Workbook()
    ws = wb.active
    ws.title = "النتائج"
    ws.sheet_view.rightToLeft = True
    ws.append(["اللوحة", "نوع المركبة", "رقم الشاسيه", "الجهة الطالبة", "الشارع / الموقع", "تاريخ المرور"])
    for r in rows:
        ws.append([r["plate"], r["vtype"], r["vin"], r["requester"], r["street"], r["record_date"]])
    for i, r in enumerate(rows, start=2):
        ws.cell(row=i, column=1).number_format = "@"
        url = maps_url(r["street"], r["link"], r["lat"], r["lon"], city)
        if url and r["street"]:
            c = ws.cell(row=i, column=5)
            c.hyperlink = url
            c.style = "Hyperlink"
    wb.save(path)
    return path
