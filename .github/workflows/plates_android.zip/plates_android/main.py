"""تطبيق مطابقة اللوحات للأندرويد (Kivy). الواجهة فقط؛ المنطق في core.py."""
import os
import threading
import webbrowser
from datetime import date

from kivy.app import App
from kivy.clock import Clock, mainthread
from kivy.core.text import LabelBase
from kivy.metrics import dp
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.button import Button
from kivy.uix.gridlayout import GridLayout
from kivy.uix.label import Label
from kivy.uix.scrollview import ScrollView
from kivy.uix.tabbedpanel import TabbedPanel, TabbedPanelItem
from kivy.uix.textinput import TextInput
from kivy.uix.togglebutton import ToggleButton
from kivy.utils import escape_markup, platform

import core

# ------------------------------------------------------------------ الخط العربي + تشكيل الحروف
_FONTS = [
    "fonts/arabic.ttf",                                   # ضع خطاً هنا لو أردت تضمينه في التطبيق
    "/system/fonts/NotoNaskhArabic-Regular.ttf", "/system/fonts/NotoNaskhArabicUI-Regular.ttf",
    "/system/fonts/NotoSansArabic-Regular.ttf", "/system/fonts/NotoSansArabicUI-Regular.ttf",
    "/system/fonts/DroidSansArabic.ttf",
    "C:/Windows/Fonts/arial.ttf", "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf",
]
_font = next((p for p in _FONTS if os.path.exists(p)), None)
if _font:
    LabelBase.register("AR", fn_regular=_font)
FONT = "AR" if _font else "Roboto"

try:
    import arabic_reshaper
    from bidi.algorithm import get_display

    def ar(s):
        return get_display(arabic_reshaper.reshape(s)) if s else ""
except Exception:  # بدون المكتبتين تظهر الحروف منفصلة
    def ar(s):
        return s


def open_url(url: str):
    if not url:
        return
    if platform == "android":
        try:
            from jnius import autoclass
            Intent, Uri = autoclass("android.content.Intent"), autoclass("android.net.Uri")
            act = autoclass("org.kivy.android.PythonActivity").mActivity
            act.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
            return
        except Exception:
            pass
    webbrowser.open(url)


def pick_file(callback):
    """يفتح منتقي الملفات ويعيد مساراً محلياً قابلاً للقراءة."""
    if platform == "android":
        from androidstorage4kivy import Chooser, SharedStorage

        def _cb(uris):
            if uris:
                path = SharedStorage().copy_from_shared(uris[0])
                Clock.schedule_once(lambda dt: callback(path))
        Chooser(_cb).choose_content("*/*")
    else:
        from plyer import filechooser
        filechooser.open_file(on_selection=lambda sel: sel and callback(sel[0]))


# ------------------------------------------------------------------ عناصر واجهة بالخط العربي
class ALabel(Label):
    def __init__(self, **kw):
        kw.setdefault("font_name", FONT)
        kw.setdefault("halign", "right")
        kw.setdefault("valign", "middle")
        super().__init__(**kw)


class AButton(Button):
    def __init__(self, **kw):
        kw.setdefault("font_name", FONT)
        kw.setdefault("size_hint_y", None)
        kw.setdefault("height", dp(46))
        if "text" in kw:
            kw["text"] = ar(kw["text"])
        super().__init__(**kw)


class AToggle(ToggleButton):
    def __init__(self, **kw):
        kw.setdefault("font_name", FONT)
        kw.setdefault("size_hint_y", None)
        kw.setdefault("height", dp(42))
        kw["text"] = ar(kw["text"])
        super().__init__(**kw)


class AInput(TextInput):
    def __init__(self, hint="", **kw):
        kw.setdefault("font_name", FONT)
        kw.setdefault("multiline", False)
        kw.setdefault("size_hint_y", None)
        kw.setdefault("height", dp(44))
        super().__init__(hint_text=ar(hint), **kw)


class ResultList(ScrollView):
    """قائمة نتائج: كل نتيجة بطاقة نصية، واسم الشارع رابط نشط يفتح خرائط جوجل."""

    def __init__(self, **kw):
        super().__init__(**kw)
        self.grid = GridLayout(cols=1, size_hint_y=None, spacing=dp(6), padding=dp(4))
        self.grid.bind(minimum_height=self.grid.setter("height"))
        self.add_widget(self.grid)

    def clear(self):
        self.grid.clear_widgets()

    def add_text(self, txt):
        lbl = ALabel(text=ar(txt), size_hint_y=None, height=dp(34))
        lbl.bind(width=lambda w, v: setattr(w, "text_size", (v - dp(12), None)))
        self.grid.add_widget(lbl)

    def add_record(self, r, city, show_entity=False):
        urls = {"0": core.maps_url(r["street"], r["link"], r["lat"], r["lon"], city)}
        l1 = f"اللوحة: {r['plate']}   النوع: {r['vtype']}"
        extra = []
        if show_entity:
            if r.get("vin"):
                extra.append(f"الشاسيه: {r['vin']}")
            if r.get("requester"):
                extra.append(f"الجهة: {r['requester']}")
        street = ar(r["street"]) if r["street"] else ""
        link = (f"[ref=0][color=2979ff][u]{escape_markup(street)}[/u][/color][/ref]" if street and urls["0"]
                else escape_markup(street))
        text = "\n".join([escape_markup(ar(l1))] + [escape_markup(ar(e)) for e in extra]
                         + [link, escape_markup(ar(f"التاريخ: {r['record_date']}"))])
        lbl = ALabel(text=text, markup=True, size_hint_y=None)
        lbl.urls = urls
        lbl.bind(on_ref_press=lambda inst, ref: open_url(inst.urls.get(ref, "")))
        lbl.bind(width=lambda w, v: setattr(w, "text_size", (v - dp(12), None)))
        lbl.bind(texture_size=lambda w, ts: setattr(w, "height", ts[1] + dp(16)))
        self.grid.add_widget(lbl)


MAX_SHOW = 300


class PlatesApp(App):
    title = "Plates Match"

    def build(self):
        self.conn = core.get_conn(os.path.join(self.user_data_dir, "plates.db"))
        self.lock = threading.Lock()
        self.last_match = []
        self.picked_daily = None
        self.picked_targets = None
        self.target_rows = []

        root = BoxLayout(orientation="vertical", padding=dp(6), spacing=dp(4))
        self.status = ALabel(text="", size_hint_y=None, height=dp(30))
        self.city = AInput("المدينة / الحي (يُضاف لبحث الخريطة)")
        root.add_widget(self.status)
        root.add_widget(self.city)

        tp = TabbedPanel(do_default_tab=False, tab_width=dp(170))
        tp.add_widget(self._tab1())
        tp.add_widget(self._tab2())
        root.add_widget(tp)
        self.refresh_stats()
        return root

    # -------------------------------------------------------------- تاب 1
    def _tab1(self):
        tab = TabbedPanelItem(text=ar("السجلات"), font_name=FONT)
        box = BoxLayout(orientation="vertical", spacing=dp(4), padding=dp(4))
        self.daily_lbl = ALabel(text="", size_hint_y=None, height=dp(26))
        self.day_in = AInput("تاريخ الحركة YYYY-MM-DD", text=date.today().isoformat(), halign="center")
        box.add_widget(AButton(text="اختيار ملف الحركة اليومية (Excel/CSV)", on_release=self.pick_daily))
        box.add_widget(self.daily_lbl)
        box.add_widget(self.day_in)
        box.add_widget(AButton(text="دمج في قاعدة البيانات", on_release=self.do_import))
        self.q_plate, self.q_street = AInput("بحث: اللوحة (بداية أو كاملة)"), AInput("بحث: الشارع يحتوي")
        self.q_from, self.q_to = AInput("من تاريخ"), AInput("إلى تاريخ")
        row = BoxLayout(size_hint_y=None, height=dp(44), spacing=dp(4))
        row.add_widget(self.q_to)
        row.add_widget(self.q_from)
        for w in (self.q_plate, self.q_street, row):
            box.add_widget(w)
        box.add_widget(AButton(text="بحث", on_release=self.do_search))
        self.res1 = ResultList()
        box.add_widget(self.res1)
        tab.add_widget(box)
        return tab

    def pick_daily(self, *_):
        pick_file(lambda p: (setattr(self, "picked_daily", p),
                             setattr(self.daily_lbl, "text", ar("الملف: " + os.path.basename(p)))))

    def do_import(self, *_):
        if not self.picked_daily:
            return self.set_status("اختر ملفاً أولاً")
        path, day = self.picked_daily, self.day_in.text.strip() or date.today().isoformat()

        def work():
            with self.lock:
                try:
                    a, d = core.import_file(self.conn, path, day,
                                            progress=lambda n: self.set_status(f"جاري الدمج... {n:,}"))
                    self.set_status(f"أُضيف {a:,} — مكرر/متجاهل {d:,}")
                except Exception as e:
                    self.set_status(f"خطأ: {e}")
            self.refresh_stats()
        threading.Thread(target=work, daemon=True).start()

    def do_search(self, *_):
        rows = core.search_records(self.conn, self.q_plate.text, self.q_street.text,
                                   self.q_from.text, self.q_to.text, MAX_SHOW)
        self.res1.clear()
        for r in rows:
            r["requester"] = ""
            self.res1.add_record(r, self.city.text)
        if not rows:
            self.res1.add_text("لا توجد نتائج")

    # -------------------------------------------------------------- تاب 2
    def _tab2(self):
        tab = TabbedPanelItem(text=ar("المطابقة"), font_name=FONT)
        box = BoxLayout(orientation="vertical", spacing=dp(4), padding=dp(4))
        self.entity = AInput("الجهة الطالبة (اختياري)")
        self.paste = AInput("ألصق اللوحات: سطر لكل لوحة (أو لوحة , جهة , شاسيه)", multiline=True, height=dp(110))
        self.tgt_lbl = ALabel(text="", size_hint_y=None, height=dp(26))
        self.latest = AToggle(text="آخر مرور فقط")
        for w in (self.entity, self.paste):
            box.add_widget(w)
        box.add_widget(AButton(text="أو: اختيار ملف الجهة (Excel/CSV)", on_release=self.pick_targets))
        box.add_widget(self.tgt_lbl)
        box.add_widget(self.latest)
        box.add_widget(AButton(text="تنفيذ المطابقة", on_release=self.do_match))
        self.summary = ALabel(text="", size_hint_y=None, height=dp(30))
        box.add_widget(self.summary)
        self.res2 = ResultList()
        box.add_widget(self.res2)
        box.add_widget(AButton(text="تصدير النتائج Excel", on_release=self.do_export))
        tab.add_widget(box)
        return tab

    def pick_targets(self, *_):
        def got(p):
            try:
                self.target_rows = core.targets_from_file(p, self.entity.text.strip())
                self.tgt_lbl.text = ar(f"{os.path.basename(p)}: {len(self.target_rows):,} لوحة")
            except Exception as e:
                self.tgt_lbl.text = ar(f"خطأ: {e}")
        pick_file(got)

    def do_match(self, *_):
        targets = self.target_rows + core.parse_pasted(self.paste.text, self.entity.text.strip())
        if not targets:
            return self.set_status("أدخل لوحات أو اختر ملفاً")
        latest = self.latest.state == "down"

        def work():
            with self.lock:
                rows, unmatched, total = core.run_match(self.conn, targets, latest)
            self.show_match(rows, unmatched, total)
        self.set_status("جاري المطابقة...")
        threading.Thread(target=work, daemon=True).start()

    @mainthread
    def show_match(self, rows, unmatched, total):
        self.last_match = rows
        self.summary.text = ar(f"مطلوب {total:,} | ظهر {total - len(unmatched):,} | مرورات {len(rows):,}")
        self.res2.clear()
        for r in rows[:MAX_SHOW]:
            self.res2.add_record(r, self.city.text, show_entity=True)
        if len(rows) > MAX_SHOW:
            self.res2.add_text(f"عُرض أول {MAX_SHOW} — الباقي في ملف التصدير")
        if unmatched:
            self.res2.add_text(f"لم تظهر ({len(unmatched)}): " + "، ".join(u["plate"] for u in unmatched[:40]))
        self.set_status("تمت المطابقة")

    def do_export(self, *_):
        if not self.last_match:
            return self.set_status("لا توجد نتائج للتصدير")
        path = os.path.join(self.user_data_dir, f"matches_{date.today()}.xlsx")
        core.export_xlsx(self.last_match, path, self.city.text)
        if platform == "android":
            try:
                from androidstorage4kivy import SharedStorage
                SharedStorage().copy_to_shared(path)
                return self.set_status("تم الحفظ في مجلد المستندات (Documents)")
            except Exception as e:
                return self.set_status(f"تعذر الحفظ: {e}")
        self.set_status(f"تم الحفظ: {path}")

    # -------------------------------------------------------------- مساعدات
    @mainthread
    def set_status(self, msg):
        self.status.text = ar(msg)

    @mainthread
    def refresh_stats(self):
        s = core.stats(self.conn)
        if self.status.text == "" or self.status.text.startswith(ar("عدد")):
            self.status.text = ar(f"عدد السجلات: {s['rows']:,}")


if __name__ == "__main__":
    PlatesApp().run()
